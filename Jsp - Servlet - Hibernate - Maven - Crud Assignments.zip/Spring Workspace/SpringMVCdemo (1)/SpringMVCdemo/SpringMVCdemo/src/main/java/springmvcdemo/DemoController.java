package springmvcdemo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DemoController {

	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("name", "jay");
		List<String> names = new ArrayList<String>();
		names.add("hello");
		names.add("samyak");
		model.addAttribute("names", names);
		return "index";
	}

	@RequestMapping("/add")
	public ModelAndView check(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("display");
		mv.addObject("result", "i am samyak");
		return mv;

	}

	@RequestMapping("/login")
	public String login() {
		return "request";
	}

	@RequestMapping(path="/request",method=RequestMethod.POST)
	public String handlerequest(@ModelAttribute(Employee emp))
	{
	System.out.println(emp);


	return "request";
	}

}