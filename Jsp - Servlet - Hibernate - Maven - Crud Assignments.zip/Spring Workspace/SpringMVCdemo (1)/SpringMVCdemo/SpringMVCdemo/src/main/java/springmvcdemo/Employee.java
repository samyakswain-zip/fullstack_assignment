package springmvcdemo;

public class Employee {
	String Email;
	String username;
	String contactno;

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	@Override
	public String toString() {
		return "Employee [Email=" + Email + ", username=" + username + ", contactno=" + contactno + "]";
	}

}
