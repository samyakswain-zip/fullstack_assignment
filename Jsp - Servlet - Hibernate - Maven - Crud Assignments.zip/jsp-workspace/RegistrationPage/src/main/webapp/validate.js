$(document).ready(function () {
    $(".class-btn").on("click", function () {

        var firstname = $('#fname').val();
        var lastname = $('#lname').val();
        var email = $('#email').val();
        var password = $('#psw').val();
        var password1 = $('#psw-confirm').val();
        var age = $("#age").val();

        // Hiding error messages 
        $('.errorMsg').hide();

        if (checkFirstname(fname) == false) {
            $('#errorfirstname').show();
            return false;
        } else if (checkLastname(lname) == false) {
            $('#errorlastname').show();
            return false;
        } else if (checkEmail(email) == false) {
            $('#erroremail').show();
            return false;
        } else if (checkPassword(psw) == false) {
            $('#errorpassword').show();
            return false;
        } else {
            alert("successful")
        }

        function checkEmail(email) {
            //regular expression for email
            var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i)
            if (pattern.test(email)) {
                return true;
            } else {
                return false;
            }

            function checkPassword(psw){
                //regular expression for password
                   var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/;
                   if(pattern.test(psw)){
                       return true;
                   }else{
                       return false;
                   }
               }
        }



    });









});